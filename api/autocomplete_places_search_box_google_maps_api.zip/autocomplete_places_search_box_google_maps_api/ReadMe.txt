Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/autocomplete-places-search-box-google-maps-javascript-api/

============ Instruction ============
Open the "index.html" file on the browser and search for a location.


============ May I Help You ===========
If you have any query about this script, send us by posting a comment here - http://www.codexworld.com/autocomplete-places-search-box-google-maps-javascript-api/#respond